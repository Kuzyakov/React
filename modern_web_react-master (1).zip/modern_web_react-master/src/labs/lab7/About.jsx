function About() {
    return(
        <h1>Катя, Сережа и Илья!</h1>
    )
}

export default About
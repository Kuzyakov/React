import FeedbackForm from './FeedbackForm';
function Lab5() {
    return (
        <div>
            <h3>Свяжитесь с нами</h3>
            <FeedbackForm />
        </div>
    )
}

export default Lab5
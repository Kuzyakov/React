function Lab3() {
    return (
        <h3>Я лабораторная 3</h3>
    )
}

export default Lab3
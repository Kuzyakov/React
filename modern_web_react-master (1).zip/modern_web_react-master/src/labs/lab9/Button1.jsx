import React from "react";

const Button1 = ({label, onclick}) =>{
    return <button onClick={onclick}>{label}</button>
  }
export default Button1
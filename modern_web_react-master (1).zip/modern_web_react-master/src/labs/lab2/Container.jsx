import React from 'react';

function Container({ children }) {
  return (
    <div>
      {children}
    </div>
  );
}

export default Container;
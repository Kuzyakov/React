function Lab6() {
    return (
        <h3>Я лабораторная 6</h3>
    )
}

export default Lab6